﻿
namespace OlomowoRzucakClicker
{
    internal class HttpClient : System.Net.Http.HttpClient
    {
    }
}